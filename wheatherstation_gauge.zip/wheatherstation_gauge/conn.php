<?php
$conn = mysqli_connect('localhost', 'user', 'password', 'db_table');  
date_default_timezone_set("Europe/Rome");
if (! $conn) {  
         die("Connection failed" . mysqli_connect_error());  
}
?>